import { Text } from "@chakra-ui/react";

function InsufficientBalance() {
  return <Text>Insufficient Balance</Text>;
}

export default InsufficientBalance;
