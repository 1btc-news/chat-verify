import { useAtom, useSetAtom } from "jotai";
import { loadable } from "jotai/utils";
import { accountDataAtom, fetchAccountDataAtom } from "../constants";

export const useAccountData = () => {
  const accountDataLoader = loadable(fetchAccountDataAtom);
  const [accountData] = useAtom(accountDataLoader);
  const setAccountData = useSetAtom(accountDataAtom);

  const isLoading = accountData.state === "loading";
  const hasError = accountData.state === "hasError" && "error" in accountData;
  const hasData = accountData.state === "hasData";

  const error = hasError ? accountData.error : undefined;
  const data = hasData ? accountData.data : undefined;

  if (hasData && data) {
    setAccountData(data);
  }

  return { isLoading, hasError, hasData, error, data };
};
